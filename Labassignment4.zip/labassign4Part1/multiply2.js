
function fnValidatenum1(){
       num1 = document.getElementById("firstNumber").value;
       num2=document.getElementById("secondNumber").value;

	if( (num1 | -2147483648) == num1){
	alert("Sorry first number can't be negative number");
	return false;
         }
         if( (num2 | -2147483648) == num2){ 	
              alert("Sorry number can't be negative number");
         	 return false;
        }
           document.getElementById("result").innerHTML = num1 * num2;
         }
	