function DisplayTable(){
  var colStart = parseInt(document.getElementById("startCol").value);
  var rowStart = parseInt(document.getElementById("startRow").value);
  var rowEnd = parseInt(document.getElementById("endRow").value);
  
  /* create a buffer variable for the new html code & put a opening table tag in it (with a border for clearity) */
  var htmlBuffer = "<table border='1'>";
  
  for (var i = rowStart; i <= rowEnd; i++){
    /* add a opening table row tag to the buffer */
    htmlBuffer += "<tr>";
    
    for (var j = colStart; j <= colStart; j++) {
      /* add a table cell with the multiplication inside it to the buffer */
      htmlBuffer += "<td>"+ (i*j) + "</td>";
    }
    
    /* add a closing table row tag to the buffer */
    htmlBuffer += "</tr>";
  }
  
  /* add a closing table tag to the buffer */
  htmlBuffer += "</table>";
  
  /* print/put generated html code inside the DIV element */
  document.getElementById("multiTable").innerHTML = htmlBuffer;
}