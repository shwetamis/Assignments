describe("MathUtils", function() {
    var calc;
 
    // //This will be called before running each spec
     beforeEach(function() {
        calc = new MathUtils();
     });
 
        it("This will throw an error in Multiplication operation when the number is negative", function() {
                expect(calc.multiply(10, 2)).toEqual(20);
                console.log("Number is not a negative number")
        });


       it("Testing for getting positive number", function(){
                calc.getPositive(11, 2);
                 expect(true).toEqual(true);
                 console.log("Number is a positive Number")
 });



       it("Testing to check if number or string", function(){
                expect(calc.checkNum('hi', 7)).toEqual(70);
                 console.log("Input is not a number")
 });

      
});