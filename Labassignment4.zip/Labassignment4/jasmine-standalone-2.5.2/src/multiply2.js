
 MathUtils = function() {
 };
 
 MathUtils.prototype.multiply= function(number1,number2) {


      if (number1===0 ) {
     throw new Error("There is a negative numbers");
    }
     
    else {
         return number1 * number2;
         console.log( number1 * number2)
}
    }



MathUtils.prototype.getPositive = function(number1,number2) {
 if (number1 === 0|| isNaN(number1)) {
       return number1 * number2;
         console.log("Number is a Positive Number") ;
    }
 

}

MathUtils.prototype.checkNum = function(number1,number2){
if(number1.isString) {
    throw new Error("input is not a Number");
        //result.toString();
       // result = "input is not a number";
    } else {
       return number1 * number2;
         console.log("Input is a valid number") ;
    }
}



		