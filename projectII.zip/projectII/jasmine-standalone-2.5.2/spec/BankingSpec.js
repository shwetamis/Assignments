describe("BankingUtils", function(){
    var citi;

    beforeEach(function(){
        citi = new BankingUtils(1000, 4, 10 );
    })

    it("Testing spy for getting calculating interest", function(){
    
        expect(citi.calculateInterest()).toEqual(400);
    })


describe("New checkCreditScore" ,function(){
    var citi;
    beforeEach(function(){
        citi= new BankingUtils(1000,4,10);
 
})
    it("check for pass credit score of 400+",function(){
        expect(citi.checkCreditScore(500)).toBeTruthy();
    })
});

});
