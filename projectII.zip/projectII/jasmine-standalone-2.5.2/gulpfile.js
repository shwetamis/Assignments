
// Include gulp
var gulp = require('gulp');

// Include plugins
var jasmine = require('gulp-jasmine');

// npm install gulp-uglify --save-dev 
var uglify =  require('gulp-uglify');
var source      = require('vinyl-source-stream'); // makes browserify bundle compatible with gulp
var streamify   = require('gulp-streamify');
var browserify  = require('browserify');
var concat = require('gulp-concat');
var browserSync = require('browser-sync');

// compress js with uglify
gulp.task('js', function(){
   return gulp.src('spec/*.js')
     // .pipe(concat('src/BankingSpec.js'))
    .pipe(jasmine())
   .pipe(uglify())
   .pipe(gulp.dest('build/scripts/'));
});

// task to copy the html files to build html and to keep watch 
gulp.task('html', function() {
   gulp.src(['src/html/bankingRunner.html'])
   .pipe(gulp.dest('build/html/'))
    .pipe(browserSync.reload({
       stream:true
   }));
});

gulp.task('default',['js','html'], function(){})