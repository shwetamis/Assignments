BankingUtils = function (principal, roi, time){
    this.principal = principal;
    this.roi = roi;
    this.time = time;
};
   

BankingUtils.prototype.getPrincipal = function(){
    return this.principal;
};

BankingUtils.prototype.getROI =function(){
    return this.roi;
}

BankingUtils.prototype.getTime = function(){
    return this.time;
}
BankingUtils.prototype.calculateInterest =function(){
    // formula ptr/ 100
    val =  (this.getPrincipal() * this.getROI() * this.getTime() ) /100;
    return val;
}

 BankingUtils.prototype.checkCreditScore= function(creditScore){
     if(creditScore <400){
 console.log("Sorry credit score is "+creditScore)
 return false;
    }else {

 console.log("Your credit score is good"+creditScore)

 return true;

     }
   

 }
 