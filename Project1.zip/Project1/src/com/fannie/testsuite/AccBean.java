package com.fannie.testsuite;

public class AccBean {

}
