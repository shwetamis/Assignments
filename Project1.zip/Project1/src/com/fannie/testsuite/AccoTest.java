package com.fannie.testsuite;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.BeforeClass;
import org.junit.Test;

public class AccoTest {

	static AccounDB adb=null;
	static AccBean bean =null;
	
	@BeforeClass
 	public static void accObjINIT()
	{
	System.out.println("Before class called from AccoTEST");
	adb= new AccounDB();
	bean =new AccBean();

	}
	
	@Test(timeout=500)
	public void updatePassAcc()
	{
		assertEquals("Testing to check Account Pass", true, adb.updateAcc());// it says value is coming form edb.insertEmployee(bean) that we need to check for pass

	}
	@Test(timeout=500)
	public void updateFailAcc()
	{
		assertNotEquals("Testing to check Account Fail", false, adb.getAccounts());// it says value is coming form edb.insertEmployee(bean) that we need to check for pass

	} 
	@Test(timeout=500)
	public void insertPassAccount() 
    { 
	
		assertEquals("Testing to check Account Pass", true, adb.insertAccount(bean));// it says value is coming form edb.insertEmployee(bean) that we need to check for pass
	
	}

}
