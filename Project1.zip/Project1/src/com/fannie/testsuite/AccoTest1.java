package com.fannie.testsuite;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.BeforeClass;
import org.junit.Test;



public class AccoTest1 {

	static AccounDB adb=null;
	static AccBean bean =null;
	
	
	@BeforeClass
 	public static void accObjINIT()
	{
	System.out.println("Before class called from AccoTEST1");
	adb= new AccounDB();
	bean =new AccBean();

	}
	@Test
	public void getAccountNotNullTest() 
{
	assertNotNull("Expect Not Null after getting emp",adb.getAccounts());
}
	
	/*@Test
	public void getAccountNull()
{
	assertNull("Expect  Null after getting emp",adb.getAccounts());
}*/
	
}
