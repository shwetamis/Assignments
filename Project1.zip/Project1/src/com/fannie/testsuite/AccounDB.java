package com.fannie.testsuite;

import com.fannie.beans.Account;
import com.fannie.dao.AccountDao;
import com.fannie.interfaces.IAccountDAO;

public class AccounDB {
	
	public boolean updateAcc() {
IAccountDAO dao = new AccountDao();
		
	try {
			Thread.sleep(100); 
			//insert
			System.out.println( dao.updateAcc(2,500));
					
		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	return true;
	}
	
	public boolean insertAccount(AccBean bean) {
		IAccountDAO dao = new AccountDao();
		
		try {
			Thread.sleep(100); 
			//insert
			System.out.println( dao.insertBatchAccount());
					
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;
	} 
	public AccBean getAccounts(){
		IAccountDAO dao = new AccountDao();
		
		try {
			Thread.sleep(100);
			// Return all Accounts
					for (Account temp: dao.getAllAccs() ){
					 System.out.println(temp);
					}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new AccBean();
		
	}
	
	
}
